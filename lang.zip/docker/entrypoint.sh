#!/bin/sh
set -eu

APP_ROOT=/var/www/html
cd "$APP_ROOT"

mkdir -p \
    storage/app/public \
    storage/framework/cache/data \
    storage/framework/sessions \
    storage/framework/views \
    storage/logs \
    bootstrap/cache

# The storage directory is a shared volume, so its ownership can drift.
chown -R www-data:www-data storage bootstrap/cache

if [ -d "$APP_ROOT/.env" ]; then
    echo "ERROR: $APP_ROOT/.env is a directory. Create a .env file next to docker-compose.yml and restart." >&2
    exit 1
fi

if [ -f "$APP_ROOT/.env" ]; then
    chmod 666 "$APP_ROOT/.env" 2>/dev/null || true
fi

has_env_key=false
if [ -f "$APP_ROOT/.env" ] && grep -qE '^[[:space:]]*APP_KEY=.+' "$APP_ROOT/.env"; then
    has_env_key=true
fi

if [ -z "${APP_KEY:-}" ] && [ "$has_env_key" = "false" ]; then
    generated_key="$(gosu www-data php artisan key:generate --show --no-ansi 2>/dev/null | tr -d '\r\n')"

    if [ -n "$generated_key" ]; then
        if [ -f "$APP_ROOT/.env" ]; then
            printf '\nAPP_KEY=%s\n' "$generated_key" >> "$APP_ROOT/.env"
        else
            printf 'APP_KEY=%s\n' "$generated_key" > "$APP_ROOT/.env"
        fi
    fi
fi

if [ "${RUN_INIT:-false}" = "true" ]; then
    gosu www-data php artisan migrate --force

    if [ "${APP_SEED:-true}" = "true" ] && ! gosu www-data php -r '
        $pdo = new PDO(
            "mysql:host=" . getenv("DB_HOST") . ";port=" . (getenv("DB_PORT") ?: "3306") . ";dbname=" . getenv("DB_DATABASE"),
            getenv("DB_USERNAME"),
            getenv("DB_PASSWORD")
        );
        exit(((int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn()) > 0 ? 0 : 1);
    ' 2>/dev/null; then
        gosu www-data php artisan db:seed --class=InstallationSeeder --force
        gosu www-data php artisan db:seed --class=AddSuperAdminSeeder --force
    fi

    touch storage/installed
    chown www-data:www-data storage/installed
fi

case "${1:-}" in
    */supervisord|supervisord)
        exec "$@"
        ;;
esac

exec gosu www-data "$@"
