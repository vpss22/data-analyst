#!/bin/sh
set -e

# The app creates a database per school, so its user needs cluster-wide rights.
mariadb --protocol=socket -uroot -p"$MARIADB_ROOT_PASSWORD" <<EOSQL
GRANT ALL PRIVILEGES ON *.* TO '$MARIADB_USER'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;
EOSQL
