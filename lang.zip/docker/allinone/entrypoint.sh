#!/bin/sh
set -eu

APP_ROOT=/var/www/html
SOCKET=/run/mysqld/mysqld.sock
cd "$APP_ROOT"

mkdir -p \
    storage/app/public \
    storage/framework/cache/data \
    storage/framework/sessions \
    storage/framework/views \
    storage/logs \
    bootstrap/cache \
    /run/mysqld

chown -R www-data:www-data storage bootstrap/cache
chown mysql:mysql /run/mysqld /var/lib/mysql 2>/dev/null || true

if [ -d "$APP_ROOT/.env" ]; then
    echo "ERROR: $APP_ROOT/.env is a directory. Create a .env file next to the compose file and restart." >&2
    exit 1
fi

if [ -f "$APP_ROOT/.env" ]; then
    chmod 666 "$APP_ROOT/.env" 2>/dev/null || true
fi

has_env_key=false
if [ -f "$APP_ROOT/.env" ] && grep -qE '^[[:space:]]*APP_KEY=.+' "$APP_ROOT/.env"; then
    has_env_key=true
fi

if [ -z "${APP_KEY:-}" ] && [ "$has_env_key" = "false" ]; then
    generated_key="$(gosu www-data php artisan key:generate --show --no-ansi 2>/dev/null | tr -d '\r\n')"

    if [ -n "$generated_key" ]; then
        if [ -f "$APP_ROOT/.env" ]; then
            printf '\nAPP_KEY=%s\n' "$generated_key" >> "$APP_ROOT/.env"
        else
            printf 'APP_KEY=%s\n' "$generated_key" > "$APP_ROOT/.env"
        fi
    fi
fi

DB_NAME="${DB_DATABASE:-laravel}"
DB_USER="${DB_USERNAME:-eschool}"
DB_PASS="${DB_PASSWORD:-eschool}"

if [ ! -d /var/lib/mysql/mysql ]; then
    echo "Initializing MariaDB data directory"
    mariadb-install-db --user=mysql --datadir=/var/lib/mysql --skip-test-db >/dev/null
fi

rm -f "$SOCKET" /run/mysqld/mysqld.pid

echo "Starting MariaDB for initialization"
mariadbd --user=mysql --datadir=/var/lib/mysql --socket="$SOCKET" \
    --pid-file=/run/mysqld/mysqld.pid >/run/mysqld/init.log 2>&1 &
INIT_PID=$!

i=0
until mariadb-admin --socket="$SOCKET" -uroot ping >/dev/null 2>&1; do
    i=$((i + 1))
    if [ "$i" -gt 60 ]; then
        echo "ERROR: MariaDB did not start. Log:" >&2
        cat /run/mysqld/init.log >&2
        exit 1
    fi
    sleep 1
done

escaped_pass="$(printf '%s' "$DB_PASS" | sed "s/'/''/g")"

echo "Ensuring database and grants"
mariadb --socket="$SOCKET" -uroot <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${escaped_pass}';
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${escaped_pass}';
ALTER USER '${DB_USER}'@'localhost' IDENTIFIED BY '${escaped_pass}';
ALTER USER '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${escaped_pass}';
GRANT ALL PRIVILEGES ON *.* TO '${DB_USER}'@'localhost' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO '${DB_USER}'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL

if [ "${RUN_INIT:-false}" = "true" ]; then
    gosu www-data php artisan migrate --force

    if [ "${APP_SEED:-true}" = "true" ] && ! gosu www-data php -r '
        $pdo = new PDO(
            "mysql:host=127.0.0.1;port=3306;dbname=" . getenv("DB_DATABASE"),
            getenv("DB_USERNAME"),
            getenv("DB_PASSWORD")
        );
        exit(((int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn()) > 0 ? 0 : 1);
    ' 2>/dev/null; then
        gosu www-data php artisan db:seed --class=InstallationSeeder --force
        gosu www-data php artisan db:seed --class=AddSuperAdminSeeder --force
    fi

    touch storage/installed
    chown www-data:www-data storage/installed
fi

echo "Stopping initialization MariaDB"
mariadb-admin --socket="$SOCKET" -uroot shutdown >/dev/null 2>&1 || kill "$INIT_PID" 2>/dev/null || true
wait "$INIT_PID" 2>/dev/null || true
rm -f "$SOCKET" /run/mysqld/mysqld.pid

case "${1:-}" in
    */supervisord|supervisord)
        exec "$@"
        ;;
esac

exec gosu www-data "$@"
