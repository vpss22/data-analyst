#!/usr/bin/env bash
# Idempotent code deploy for eSchool on Debian (no Docker).
#
# Usage:
#   sudo SRC=/path/to/htdocs ./deploy.sh
#
# Optional env:
#   APP_DIR     (default /var/www/eschool)
#   APP_USER    (default www-data)
#   SRC         (default: repository root this script lives in)
#   SEED_MODE   auto|always|never  (default auto; only applies when storage/installed is missing)
#   PHP_VERSION (default 8.3, used for the FPM reload)

set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/eschool}"
APP_USER="${APP_USER:-www-data}"
PHP_VERSION="${PHP_VERSION:-8.3}"
SEED_MODE="${SEED_MODE:-auto}"
SRC="${SRC:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
PHP_BIN="${PHP_BIN:-php}"

die() { echo "ERROR: $*" >&2; exit 1; }
run_as() { sudo -u "$APP_USER" -H -- "$@"; }

[[ "$(id -u)" -eq 0 ]] || die "Run this script as root (sudo)."
[[ -f "$SRC/artisan" && -d "$SRC/public" ]] || die "SRC=$SRC does not look like the app root; set SRC=/path/to/app."
[[ "$APP_DIR" != "/" ]] || die "Refusing to deploy into /."
case "$SEED_MODE" in auto|always|never) ;; *) die "SEED_MODE must be auto, always or never." ;; esac
command -v rsync >/dev/null 2>&1 || die "rsync is not installed."
COMPOSER_BIN="$(command -v composer || true)"
[[ -n "$COMPOSER_BIN" ]] || die "composer is not installed; run setup-server.sh first."
command -v "$PHP_BIN" >/dev/null 2>&1 || die "php is not installed; run setup-server.sh first."

echo "==> Syncing $SRC -> $APP_DIR"
install -d -m 0755 "$APP_DIR"
rsync -a --delete \
    --exclude='/.git/' \
    --exclude='/.env' \
    --exclude='/node_modules/' \
    --exclude='/storage/' \
    --exclude='/bootstrap/cache/' \
    --exclude='/public/storage' \
    --exclude='/tests/' \
    --exclude='/phpunit.xml' \
    --exclude='/.phpunit.result.cache' \
    --exclude='/Dockerfile' \
    --exclude='/docker-compose.yml' \
    --exclude='/.dockerignore' \
    --exclude='/docker/' \
    "$SRC"/ "$APP_DIR"/

echo "==> Creating writable directories and fixing permissions"
install -d -m 0775 -o "$APP_USER" -g "$APP_USER" \
    "$APP_DIR/storage/app/public" \
    "$APP_DIR/storage/framework/cache/data" \
    "$APP_DIR/storage/framework/sessions" \
    "$APP_DIR/storage/framework/views" \
    "$APP_DIR/storage/logs" \
    "$APP_DIR/bootstrap/cache"
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} +
find "$APP_DIR" -type f -exec chmod 644 {} +
chmod -R ug+rwX "$APP_DIR/storage" "$APP_DIR/bootstrap/cache"

ENV_CREATED=false
if [[ ! -f "$APP_DIR/.env" ]]; then
    echo "==> Creating .env from deployment/debian/env.production.example"
    install -m 0640 -o "$APP_USER" -g "$APP_USER" \
        "$APP_DIR/deployment/debian/env.production.example" "$APP_DIR/.env"
    run_as "$PHP_BIN" "$APP_DIR/artisan" key:generate --force >/dev/null
    ENV_CREATED=true
fi
chown "$APP_USER:$APP_USER" "$APP_DIR/.env"
chmod 640 "$APP_DIR/.env"

echo "==> Installing PHP dependencies"
run_as "$COMPOSER_BIN" --working-dir="$APP_DIR" install \
    --no-dev --optimize-autoloader --no-interaction

if [[ "$ENV_CREATED" == "true" ]]; then
    echo
    echo ".env was created from the template and an APP_KEY was generated."
    echo "Edit $APP_DIR/.env (APP_URL, DB_*, REVERB_*, MAIL_*), then rerun this script."
    exit 0
fi

echo "==> Running migrations"
run_as "$PHP_BIN" "$APP_DIR/artisan" migrate --force

get_env() {
    local key="$1"
    grep -E "^[[:space:]]*${key}=" "$APP_DIR/.env" | tail -n 1 | cut -d= -f2- \
        | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//"
}

count_users() {
    local host port name user pass
    host="$(get_env DB_HOST)"; host="${host:-127.0.0.1}"
    port="$(get_env DB_PORT)"; port="${port:-3306}"
    name="$(get_env DB_DATABASE)"
    user="$(get_env DB_USERNAME)"
    pass="$(get_env DB_PASSWORD)"
    [[ -n "$name" && -n "$user" ]] || return 1
    MYSQL_PWD="$pass" mariadb --protocol=tcp -h"$host" -P"$port" -u"$user" -N -B \
        -e "SELECT COUNT(*) FROM \`$name\`.users" 2>/dev/null
}

if [[ ! -f "$APP_DIR/storage/installed" ]]; then
    echo "==> First install detected (storage/installed missing)"
    SEED_NOW=false
    case "$SEED_MODE" in
        always) SEED_NOW=true ;;
        never)  echo "    SEED_MODE=never: skipping seeders and install marker." ;;
        auto)
            USERS="$(count_users || true)"
            if [[ "$USERS" =~ ^[0-9]+$ && "$USERS" -gt 0 ]]; then
                echo "    Existing users found ($USERS); importing as installed."
            else
                SEED_NOW=true
            fi
            ;;
    esac

    if [[ "$SEED_NOW" == "true" ]]; then
        run_as "$PHP_BIN" "$APP_DIR/artisan" db:seed --class=InstallationSeeder --force
        run_as "$PHP_BIN" "$APP_DIR/artisan" db:seed --class=AddSuperAdminSeeder --force
    fi
    if [[ "$SEED_MODE" != "never" ]]; then
        run_as touch "$APP_DIR/storage/installed"
    fi
fi

echo "==> Storage link and cache cleanup"
run_as "$PHP_BIN" "$APP_DIR/artisan" storage:link --force
run_as "$PHP_BIN" "$APP_DIR/artisan" optimize:clear

echo "==> Restarting workers and web services"
if command -v supervisorctl >/dev/null 2>&1; then
    supervisorctl reread >/dev/null 2>&1 || true
    supervisorctl update >/dev/null 2>&1 || true
    supervisorctl restart eschool-queue-worker:* >/dev/null 2>&1 || true
    supervisorctl restart eschool-reverb >/dev/null 2>&1 || true
    supervisorctl restart eschool-scheduler >/dev/null 2>&1 || true
fi
if apache2ctl configtest >/dev/null 2>&1; then
    systemctl reload apache2 || true
fi
systemctl reload "php${PHP_VERSION}-fpm" >/dev/null 2>&1 || true

echo
echo "Deploy complete: $APP_DIR"
echo "  Check: supervisorctl status"
echo "  Logs:  $APP_DIR/storage/logs (laravel.log, queue-worker.log, reverb.log, scheduler.log)"
