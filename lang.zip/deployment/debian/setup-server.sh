#!/usr/bin/env bash
# Debian 12 server bootstrap for eSchool (no Docker).
# Installs LAMP + PHP 8.3, Composer, Supervisor, configures Apache/PHP-FPM.
#
# Usage:
#   sudo DOMAIN=eschool.example.com DB_PASSWORD='strong-password' ./setup-server.sh
#
# Optional env:
#   APP_DIR     (default /var/www/eschool)
#   DB_NAME     (default laravel)
#   DB_USER     (default eschool)
#   DB_PASSWORD (when set, the database and user are created; localhost + 127.0.0.1)
#   PHP_VERSION (default 8.3)

set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/eschool}"
DOMAIN="${DOMAIN:-_}"
DB_NAME="${DB_NAME:-laravel}"
DB_USER="${DB_USER:-eschool}"
PHP_VERSION="${PHP_VERSION:-8.3}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run this script as root (sudo)." >&2
    exit 1
fi
if [[ "$(uname -s)" != "Linux" ]]; then
    echo "This script is for Debian Linux." >&2
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive
CODENAME="$(. /etc/os-release && echo "${VERSION_CODENAME:-bookworm}")"

echo "==> Installing base packages (Debian ${CODENAME})"
apt-get update
apt-get -y install --no-install-recommends \
    lsb-release ca-certificates curl gnupg unzip rsync git sudo supervisor cron ufw

if [[ ! -f /usr/share/keyrings/deb.sury.org-php.gpg ]]; then
    curl -fsSLo /usr/share/keyrings/deb.sury.org-php.gpg https://packages.sury.org/php/apt.gpg
fi
echo "deb [signed-by=/usr/share/keyrings/deb.sury.org-php.gpg] https://packages.sury.org/php/ ${CODENAME} main" \
    > /etc/apt/sources.list.d/php.list

apt-get update
echo "==> Installing Apache, MariaDB, PHP ${PHP_VERSION}"
apt-get -y install --no-install-recommends \
    apache2 mariadb-server \
    "php${PHP_VERSION}" "php${PHP_VERSION}-cli" "php${PHP_VERSION}-fpm" \
    "php${PHP_VERSION}-mysql" "php${PHP_VERSION}-curl" "php${PHP_VERSION}-gd" \
    "php${PHP_VERSION}-mbstring" "php${PHP_VERSION}-xml" "php${PHP_VERSION}-zip" \
    "php${PHP_VERSION}-bcmath" "php${PHP_VERSION}-opcache"

if ! command -v composer >/dev/null 2>&1; then
    echo "==> Installing Composer"
    curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

echo "==> PHP settings"
for SAPI in fpm cli; do
    install -m 0644 "$SCRIPT_DIR/php-eschool.ini" "/etc/php/${PHP_VERSION}/${SAPI}/conf.d/99-eschool.ini"
done

echo "==> Apache configuration"
a2enmod rewrite headers proxy proxy_fcgi >/dev/null
a2enconf "php${PHP_VERSION}-fpm" >/dev/null
install -d -m 0755 "$APP_DIR"
sed -e "s|__APP_DIR__|${APP_DIR}|g" -e "s|__DOMAIN__|${DOMAIN}|g" \
    "$SCRIPT_DIR/apache-eschool.conf" > /etc/apache2/sites-available/eschool.conf
a2ensite eschool >/dev/null
a2dissite 000-default >/dev/null 2>&1 || true

echo "==> Supervisor programs"
for PROGRAM in queue-worker reverb scheduler; do
    sed "s|/var/www/eschool|${APP_DIR}|g" \
        "$SCRIPT_DIR/../supervisor/${PROGRAM}.conf" \
        > "/etc/supervisor/conf.d/eschool-${PROGRAM}.conf"
done

if [[ -n "${DB_PASSWORD:-}" ]]; then
    if [[ ! "$DB_NAME" =~ ^[A-Za-z0-9_]+$ || ! "$DB_USER" =~ ^[A-Za-z0-9_]+$ || "$DB_PASSWORD" == *"'"* ]]; then
        echo "DB_NAME/DB_USER must be alphanumeric+underscore and DB_PASSWORD must not contain single quotes." >&2
        exit 1
    fi

    echo "==> Creating database ${DB_NAME} and user ${DB_USER}"
    mariadb <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON *.* TO '${DB_USER}'@'localhost' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO '${DB_USER}'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL
else
    echo "==> Skipping database creation (set DB_PASSWORD to create database + user)"
fi

systemctl enable --now mariadb apache2 supervisor >/dev/null
systemctl enable --now "php${PHP_VERSION}-fpm" >/dev/null

apache2ctl configtest
systemctl reload apache2
supervisorctl reread >/dev/null
supervisorctl update >/dev/null || true

if [[ ! -f "$APP_DIR/artisan" ]]; then
    supervisorctl stop eschool-queue-worker:* eschool-reverb eschool-scheduler >/dev/null 2>&1 || true
    echo "==> App code is not deployed yet; workers stay stopped until deploy.sh runs."
fi

echo
echo "Server bootstrap complete."
echo "  PHP:        $(php -v | head -n 1)"
echo "  App dir:    ${APP_DIR}"
echo "  Site:       /etc/apache2/sites-available/eschool.conf (Domain: ${DOMAIN})"
echo "  Supervisor: /etc/supervisor/conf.d/eschool-*.conf"
echo
echo "Next:"
echo "  1. Copy the project to ${APP_DIR} and run deployment/debian/deploy.sh"
echo "  2. Open ports: ufw allow OpenSSH && ufw allow 'Apache Full' && ufw allow 9091/tcp && ufw enable"
echo "  3. Optional TLS: apt -y install certbot python3-certbot-apache && certbot --apache -d ${DOMAIN}"
