param(
    [string]$PhpPath = 'C:\xampp\php\php.exe'
)

$ErrorActionPreference = 'SilentlyContinue'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$logDir = Join-Path $root 'storage\logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

# Single-instance guard: another runner already owns this lock.
try {
    $lock = [System.IO.File]::Open(
        (Join-Path $PSScriptRoot 'workers.lock'),
        [System.IO.FileMode]::OpenOrCreate,
        [System.IO.FileAccess]::ReadWrite,
        [System.IO.FileShare]::None
    )
} catch {
    exit 0
}

function Start-QueueWorker {
    Start-Process -FilePath $PhpPath `
        -ArgumentList @('artisan', 'queue:work', '--sleep=3', '--tries=3', '--max-time=3600') `
        -WorkingDirectory $root -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logDir 'queue-worker.out.log') `
        -RedirectStandardError (Join-Path $logDir 'queue-worker.err.log') -PassThru
}

function Start-Reverb {
    Start-Process -FilePath $PhpPath `
        -ArgumentList @('artisan', 'reverb:start') `
        -WorkingDirectory $root -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logDir 'reverb.out.log') `
        -RedirectStandardError (Join-Path $logDir 'reverb.err.log') -PassThru
}

$queue = Start-QueueWorker
$reverb = Start-Reverb

while ($true) {
    Start-Sleep -Seconds 5

    if ($null -eq $queue -or $queue.HasExited) {
        $queue = Start-QueueWorker
    }

    if ($null -eq $reverb -or $reverb.HasExited) {
        $reverb = Start-Reverb
    }
}
