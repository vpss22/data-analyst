<?php

namespace App\Payments\Exceptions;

/**
 * Thrown when a gateway verification call fails or returns an unusable result.
 */
class PaymentVerificationException extends PaymentException
{
}
