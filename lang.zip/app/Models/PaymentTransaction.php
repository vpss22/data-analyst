<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Traits\DateFormatTrait;

class PaymentTransaction extends Model
{
    use HasFactory, DateFormatTrait;

    protected $fillable = ['user_id', 'amount', 'payment_gateway', 'order_id', 'payment_id', 'payment_signature', 'payment_status', 'school_id', 'type'];

    protected $appends = ['original_created_at', 'original_updated_at'];
    // protected $connection = 'mysql';

    public function student()
    {
        return $this->belongsTo(Students::class, 'student_id')->withTrashed();
    }

    /**
     * Payment proof uploaded by the parent for a manual payment.
     */
    public function file()
    {
        return $this->morphOne(File::class, 'modal');
    }

    public function getReceiptUrlAttribute()
    {
        return $this->file ? $this->file->file_url : null;
    }

    public function class()
    {
        return $this->belongsTo(ClassSchool::class, 'class_id')->withTrashed();
    }

    public function session_year()
    {
        return $this->belongsTo(SessionYear::class)->withTrashed();
    }

    public function school()
    {
        return $this->belongsTo(School::class)->withTrashed();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function scopeOwner($query)
    {
        if (Auth::user()) {
            if (Auth::user()->hasRole('Super Admin')) {
                return $query;
            }

            if (Auth::user()->hasRole('School Admin')) {
                return $query->where('school_id', Auth::user()->school_id);
            }

            if (Auth::user()->hasRole('Student')) {
                return $query->where('school_id', Auth::user()->school_id);
            }
        }

        return $query;
    }

    /**
     * Get the subscription_bill associated with the PaymentTransaction
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function subscription_bill()
    {
        return $this->hasOne(SubscriptionBill::class);
    }

    /**
     * Get the addon_subscription associated with the PaymentTransaction
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function addon_subscription()
    {
        return $this->hasOne(AddonSubscription::class);
    }

    public function getConnectionName()
    {
        // Replace this with your logic to determine the connection name
        // For example, you might get it from session or config
        return session('db_connection_name') ?? config('database.default');
    }

    public function getCreatedAtAttribute($value)
    {
        return $this->formatDateValue($value);
    }

    public function getUpdatedAtAttribute($value)
    {
        return $this->formatDateValue($value);
    }

    public function getOriginalCreatedAtAttribute()
    {
        return $this->getRawOriginal('created_at');
    }

    public function getOriginalUpdatedAtAttribute()
    {
        return $this->getRawOriginal('updated_at');
    }


    /**
     * Get all of the compulsory_fees for the PaymentTransaction
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function compulsory_fees()
    {
        return $this->hasMany(CompulsoryFee::class);
    }

    /**
     * Get all of the optional_fees for the PaymentTransaction
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function optional_fees()
    {
        return $this->hasMany(OptionalFee::class);
    }

    /**
     * Get all of the trans for the PaymentTransaction
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function transportation_payment()
    {
        return $this->hasMany(TransportationPayment::class);
    }
}
