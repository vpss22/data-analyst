<?php

namespace App\Models;

use App\Repositories\Semester\SemesterInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use App\Services\CachingService;
use App\Traits\DateFormatTrait;


class ClassSubject extends Model
{
    use HasFactory, SoftDeletes, DateFormatTrait;

    protected $fillable = ['class_id', 'subject_id', 'type', 'semester_id', 'elective_subject_group_id', 'school_id', 'session_year_id', 'syllabus_id'];

    protected $appends = ['subject_with_name'];

    public function class()
    {
        return $this->belongsTo(ClassSchool::class)->withTrashed();
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class)->withTrashed();
    }

    public function semester()
    {
        return $this->belongsTo(Semester::class)->withTrashed();
    }

    public function subjectGroup()
    {
        return $this->belongsTo(ElectiveSubjectGroup::class, 'elective_subject_group_id');
    }

    public function scopeSubjectTeacher($query, $class_section_id = null)
    {
        $user = Auth::user();
        if ($user->hasRole('Teacher')) {
            if ($class_section_id) {
                // TODO: Mahesh subject teacher teacher_id foreign key directly assigned to user
                // $subjects_ids = $user->teacher->subjects()->where('class_section_id', $class_section_id)->pluck('subject_id');
                $subjects_ids = $user->subjects()->where('class_section_id', $class_section_id)->pluck('subject_id');
            } else {
                // TODO: Mahesh subject teacher teacher_id foreign key directly assigned to user
                // $subjects_ids = $user->teacher->subjects()->pluck('subject_id');
                $subjects_ids = $user->subjects()->pluck('subject_id');
            }
            return $query->whereIn('subject_id', $subjects_ids);
        }
        return $query;
    }

    public function scopeSubjectTeacherClassTeacher($query)
    {
        $user = Auth::user();
        if ($user->hasRole('Teacher')) {
            $teacherId = Auth::user()->id;
            return $query->whereHas('subject_teacher', function ($query) use ($teacherId) {
                $query->where('teacher_id', $teacherId);
            })->where('school_id', Auth::user()->school_id);
        }
        return $query->where('school_id', Auth::user()->school_id);
    }

    public function scopeOwner($query)
    {
        if (Auth::user()) {
            if (Auth::user()->hasRole('Super Admin')) {
                return $query;
            }

            $sessionYearId = app(CachingService::class)->getSessionYear()->id;
            if (Auth::user()->hasRole('School Admin') || Auth::user()->hasRole('Teacher') || Auth::user()->hasRole('Student')) {
                return $query->where(['school_id' => Auth::user()->school_id, 'session_year_id' => $sessionYearId]);
            }
        }

        return $query;
    }

    public function subjectTeachers()
    {
        return $this->hasMany(SubjectTeacher::class, 'class_subject_id')->with('teacher');
    }

    public function scopeCurrentSemesterData($query)
    {
        $currentSemester = app(CachingService::class)->getSemester();
        if ($currentSemester) {
            $query->where(function ($query) use ($currentSemester) {
                $query->where('semester_id', $currentSemester->id)->orWhereNull('semester_id');
            });
        }
    }

    public function getSubjectWithNameAttribute()
    {
        if ($this->relationLoaded('subject')) {
            $name = $this->subject->name . ' - ' . $this->subject->type;
            if ($this->relationLoaded('class') && $this->class && $this->class->include_semesters) {
                if ($this->relationLoaded('semester') && $this->semester) {
                    $name .= ' (' . $this->semester->name . ')';
                }
            }
            return $name;
        }
        return null;
    }

    /**
     * Get all of the subject for the ClassSubject
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subject_teacher()
    {
        return $this->hasMany(SubjectTeacher::class);
    }

    public function getCreatedAtAttribute()
    {
        return $this->formatDateValue($this->getRawOriginal('created_at'));
    }

    public function getUpdatedAtAttribute()
    {
        return $this->formatDateValue($this->getRawOriginal('updated_at'));
    }
}
