<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use App\Traits\DateFormatTrait;
use App\Services\CachingService;

class OptionalFee extends Model
{
    use HasFactory, DateFormatTrait;
    use SoftDeletes;

    protected $fillable = [
        'student_id',
        'class_id',
        'payment_transaction_id',
        'fees_class_id',
        'mode',
        'cheque_no',
        'amount',
        'fees_paid_id',
        'reason',
        'date',
        'status',
        'notes',
        'school_id',
        'created_at',
        'updated_at'
    ];

    const CHEQUE_PENDING = 'Pending';
    const CHEQUE_SUCCESS = 'Success';
    const CHEQUE_FAILED  = 'Failed';

    const MANUAL_UNDER_REVIEW = 'Pending';
    const MANUAL_APPROVED     = 'Success';
    const MANUAL_REJECTED     = 'Failed';
    const MODE_MANUAL         = 'Manual';



    protected $appends = ['mode_name'];

    public function file()
    {
        return $this->morphOne(File::class, 'modal');
    }

    public function scopeOwner($query)
    {
        if (Auth::user()) {
            if (Auth::user()->hasRole('Super Admin')) {
                return $query;
            }

            if (Auth::user()->hasRole('School Admin') || Auth::user()->hasRole('Teacher')) {
                return $query->where(['school_id' => Auth::user()->school_id]);
            }

            if (Auth::user()->hasRole('Student')) {
                return $query->where(['school_id' => Auth::user()->school_id]);
            }
        }

        return $query;
    }

    public function fees_paid()
    {
        return $this->belongsTo(FeesPaid::class, 'fees_paid_id')->withTrashed();
    }

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id')->withTrashed();
    }

    public function fees_class_type()
    {
        return $this->belongsTo(FeesClassType::class, 'fees_class_id');
    }

    /**
     * Get the payment_transaction that owns the OptionalFee
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function payment_transaction()
    {
        return $this->belongsTo(PaymentTransaction::class);
    }

    // public function getModeNameAttribute()
    // {
    //     if ($this->mode == "1") {
    //         return 'Cash';
    //     } elseif ($this->mode == "2") {
    //         return 'Cheque';
    //     } else {
    //         return 'Online';
    //     }
    // }
    public function getModeNameAttribute()
    {
        if ($this->mode == "1" || $this->mode == "Cash") {
            return 'Cash';
        } elseif ($this->mode == "2" || $this->mode == "Cheque") {
            return 'Cheque';
        } elseif ($this->mode == "Manual") {
            return 'Manual';
        } else {
            return 'Online';
        }
    }
    // 4. Receipt URL Accessor
    public function getReceiptUrlAttribute()
    {
        return $this->file ? $this->file->file_url : null;
    }

    public function getCreatedAtAttribute()
    {
        return $this->formatDateValue($this->getRawOriginal('created_at'));
    }

    public function getUpdatedAtAttribute()
    {
        return $this->formatDateValue($this->getRawOriginal('updated_at'));
    }

    public function getDateAttribute($value)
    {
        return $this->formatDateOnly($value);
    }
}
