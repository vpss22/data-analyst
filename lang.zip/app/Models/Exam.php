<?php

namespace App\Models;

use App\Traits\DateFormatTrait;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use App\Services\CachingService;

class Exam extends Model
{
    use HasFactory;
    use SoftDeletes;
    use DateFormatTrait;

    protected $fillable = [
        'name',
        'session_year_id',
        'description',
        'start_date',
        'end_date',
        'school_id',
        'publish',
        'last_result_submission_date',
        'class_id'
    ];

    protected $hidden = ['created_at', 'updated_at'];

    protected $appends = ["exam_status", "exam_status_name", "has_timetable", "class_name"];

    public function class()
    {
        return $this->belongsTo(ClassSchool::class, 'class_id')->withTrashed();
    }

    public function session_year()
    {
        return $this->belongsTo(SessionYear::class, 'session_year_id')->withTrashed();
    }

    public function marks()
    {
        return $this->hasManyThrough(ExamMarks::class, ExamTimetable::class, 'exam_id', 'exam_timetable_id')->orderBy('date');
    }

    public function timetable()
    {
        return $this->hasMany(ExamTimetable::class);
    }

    public function results()
    {
        return $this->hasMany(ExamResult::class, 'exam_id');
    }

    public function semester()
    {
        return $this->belongsTo(Semester::class, 'semester_id')->withTrashed();
    }

    public function getSemesterNameAttribute()
    {
        if ($this->semester_id && $this->relationLoaded('semester') && $this->semester) {
            return $this->semester->name;
        }

        if ($this->relationLoaded('timetable')) {
            $firstTimetable = $this->timetable->first();
            if ($firstTimetable && $firstTimetable->class_subject && $firstTimetable->class_subject->semester) {
                return $firstTimetable->class_subject->semester->name;
            }
        }

        return '';
    }
    public function scopeOwner($query)
    {
        if (Auth::user()) {
            $sessionYearId = app(CachingService::class)->getSessionYear()->id;
            if (Auth::user()->school_id) {
                if (Auth::user()->hasRole('School Admin')) {
                    return $query->where(['school_id' => Auth::user()->school_id, 'session_year_id' => $sessionYearId]);
                }

                if (Auth::user()->hasRole('Teacher')) {
                    $classTeacherData = ClassTeacher::where(['teacher_id' => Auth::user()->id, 'session_year_id' => $sessionYearId])->with('class_section')->get();
                    $subjectTeacherData = SubjectTeacher::where(['teacher_id' => Auth::user()->id, 'session_year_id' => $sessionYearId])->with('class_section')->get();
                    $subjectTeacherData = $subjectTeacherData->pluck('class_section.class_id')->filter()->toArray();
                    $classIds = $classTeacherData->pluck('class_id')->filter()->toArray();
                    $classIds = array_merge($subjectTeacherData, $classIds);
                    $classIds = array_unique($classIds);
                    return $query->whereIn('class_id', $classIds)->where(['school_id' => Auth::user()->school_id, 'session_year_id' => $sessionYearId]);
                }

                if (Auth::user()->hasRole('Student')) {
                    return $query->where(['school_id' => Auth::user()->school_id, 'session_year_id' => $sessionYearId]);
                }
                return $query->where(['school_id' => Auth::user()->school_id, 'session_year_id' => $sessionYearId]);
            }
            if (!Auth::user()->school_id) {
                if (Auth::user()->hasRole('Super Admin')) {
                    return $query;
                }
                if (Auth::user()->hasRole('Guardian')) {
                    $childId = request('child_id');
                    $studentAuth = Students::where('id', $childId)->first();
                    return $query->where(['school_id' => $studentAuth->school_id, 'session_year_id' => $sessionYearId]);
                }
                return $query;
            }
        }
        return $query;
    }


    public function getExamStatusAttribute()
    {
        if ($this->relationLoaded('timetable')) {
            // $startDate = date('Y-m-d', strtotime($this->timetable->min('date')));
            // $endDate = date('Y-m-d', strtotime($this->timetable->max('date')));

            $startDate = $this->timetable->min(function ($item) {
                return $item->getRawOriginal('date');
            });

            $endDate = $this->timetable->max(function ($item) {
                return $item->getRawOriginal('date');
            });

            $currentTime = Carbon::now();
            $current_date = date($currentTime->toDateString());
            $current_time = Carbon::now();
            //  0- Upcoming, 1-On Going, 2-Completed, 3-All Details
            $exam_status = 3;
            if ($current_date == $startDate && $current_date == $endDate) {
                if (count($this->timetable)) {
                    $exam_end_time = Carbon::parse($this->timetable->first()->getRawOriginal('end_time'));
                    $exam_start_time = Carbon::parse($this->timetable->first()->getRawOriginal('start_time'));
                    if ($current_time->lt($exam_start_time)) {
                        $exam_status = "0";
                    } elseif ($current_time->gt($exam_end_time)) {
                        $exam_status = "2";
                    } else {
                        $exam_status = "1";
                    }
                }
                return $exam_status;
            } else {
                if (count($this->timetable)) {
                    if ($current_date < $startDate) {
                        $exam_status = "0"; // Upcoming
                    } elseif ($current_date >= $startDate && $current_date <= $endDate) {
                        $exam_status = "1"; // Ongoing
                    } else {
                        $exam_status = "2"; // Ended
                    }
                } else {
                    $exam_status = 0;
                }
            }

            return $exam_status;
        }

        return null;
    }

    public function getExamStatusNameAttribute()
    {
        if ($this->relationLoaded('timetable')) {
            $startDate = $this->timetable->min('date');
            $endDate = $this->timetable->max('date');

            $currentDate = now()->toDateString();
            if ($currentDate >= $startDate && $currentDate <= $endDate) {
                return "On Going"; // Upcoming = 0 , On Going = 1 , Completed = 2
            }

            if ($currentDate < $startDate) {
                return "Completed"; // Upcoming = 0 , On Going = 1 , Completed = 2
            }
            return "Upcoming"; // Upcoming = 0 , On Going = 1 , Completed = 2
        }

        return null;
    }

    public function getHasTimetableAttribute()
    {
        if ($this->relationLoaded('timetable')) {
            return count($this->timetable) > 0;
        }

        return false;
    }

    public function getPrefixNameAttribute()
    {
        return $this->name . ' # ' . $this->class->name . ' - ' . $this->class->medium->name;
    }

    public function getClassNameAttribute()
    {
        if ($this->relationLoaded('class')) {
            return $this->class->name . ' - ' . $this->class->medium->name;
        }
        return '';
    }

    public function getStartDateAttribute($value)
    {
        return $this->formatDateOnly($value);
    }

    public function getEndDateAttribute($value)
    {
        return $this->formatDateOnly($value);
    }

    public function getLastResultSubmissionDateAttribute($value)
    {
        if ($value ?? null) {
            return $this->formatDateOnly($value);
        }
        return null;
    }
}
