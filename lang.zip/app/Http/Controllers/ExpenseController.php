<?php

namespace App\Http\Controllers;

use App\Repositories\Expense\ExpenseInterface;
use App\Repositories\ExpenseCategory\ExpenseCategoryInterface;
use App\Repositories\SessionYear\SessionYearInterface;
use App\Services\BootstrapTableService;
use App\Services\CachingService;
use App\Services\ResponseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Throwable;
use Carbon\Carbon;

class ExpenseController extends Controller
{

    private ExpenseInterface $expense;
    private ExpenseCategoryInterface $expenseCategory;
    private SessionYearInterface $sessionYear;
    private CachingService $cache;

    public function __construct(ExpenseInterface $expense, ExpenseCategoryInterface $expenseCategory, SessionYearInterface $sessionYear, CachingService $cache)
    {
        $this->expense = $expense;
        $this->expenseCategory = $expenseCategory;
        $this->sessionYear = $sessionYear;
        $this->cache = $cache;
    }

    public function index()
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noAnyPermissionThenRedirect(['expense-create', 'expense-list']);

        $expenseCategory = $this->expenseCategory->builder()->pluck('name', 'id')->toArray();
        $sessionYearFullData = $this->cache->getSessionYear();

        $months = sessionYearWiseMonthYear();

        return view('expense.index', compact('expenseCategory', 'months', 'sessionYearFullData'));
    }


    public function create()
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noPermissionThenRedirect('expense-create');
    }


    public function store(Request $request)
    {
        ResponseService::noFeatureThenSendJson('Finance Management');
        ResponseService::noPermissionThenSendJson('expense-create');
        $sessionYearId = $this->cache->getSessionYear()->id;
        $request->validate([
            'ref_no' => [
                'nullable',
                Rule::unique('expenses', 'ref_no')
                    ->where(function ($query) use ($sessionYearId) {
                        return $query->where('session_year_id', $sessionYearId)->whereNull('vehicle_id')->whereNull('staff_id');
                    })
            ],
            'amount' => 'required|numeric|min:0'
        ], [
            'ref_no.unique' => 'Reference number already exists for the selected session year.'
        ]);
        try {
            DB::beginTransaction();
            $schoolSettings = $this->cache->getSchoolSettings();
            $data = [
                'category_id' => $request->category_id,
                'title' => $request->title,
                'ref_no' => $request->ref_no,
                'amount' => $request->amount,
                'date' => $request->date
                    ? Carbon::createFromFormat($schoolSettings['date_format'], $request->date)->format('Y-m-d')
                    : null,
                'description' => $request->description,
                'session_year_id' => $sessionYearId,
            ];

            $expense = $this->expense->create($data);

            DB::commit();
            ResponseService::successResponse('Data Stored Successfully');
        } catch (Throwable $e) {
            DB::rollBack();
            ResponseService::logErrorResponse($e, "Expense Controller -> Store Method");
            ResponseService::errorResponse();
        }
    }


    public function show($id)
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noPermissionThenRedirect('expense-list');
        $offset = request('offset', 0);
        $limit = request('limit', 10);
        $sort = request('sort', 'date');
        $order = request('order', 'DESC');
        $search = request('search');
        $category_id = request('category_id');
        $session_year_id = $this->cache->getSessionYear()->id;
        $month = request('month');

        // $sql = $this->expense->builder()->with('category')->select('*', DB::raw('SUM(amount) as total_salary'))->groupBy('month', 'date')->where(function ($query) use ($search) {
        //         $query->when($search, function ($query) use ($search) {
        //             $query->where(function ($query) use ($search) {
        //                 $query->where('title', 'LIKE', "%$search%")->orWhere('ref_no', 'LIKE', "%$search%")->orWhere('amount', 'LIKE', "%$search%")->orWhere('date', 'LIKE', "%$search%")->orWhere('description', 'LIKE', "%$search%")->orWhereHas('category', function ($q) use ($search) {
        //                         $q->Where('name', 'LIKE', "%$search%");
        //                     });
        //             });
        //         });
        //     });

        $sql = $this->expense->builder()->with('category')->whereNull('vehicle_id')->where(function ($query) use ($search) {
            $query->when($search, function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('title', 'LIKE', "%$search%")->orWhere('ref_no', 'LIKE', "%$search%")->orWhere('amount', 'LIKE', "%$search%")->orWhere('date', 'LIKE', "%$search%")->orWhere('description', 'LIKE', "%$search%")->orWhereHas('category', function ($q) use ($search) {
                        $q->Where('name', 'LIKE', "%$search%");
                    });
                });
            });
        });

        if ($category_id) {
            if ($category_id != 'salary') {
                $sql->where('category_id', $category_id)->whereNull('staff_id');
            } else {
                $sql->whereNotNull('staff_id');
            }
        }

        if ($session_year_id) {
            $sql->where('session_year_id', $session_year_id);
        }

        if ($month) {
            $month_year = explode('_', $month);
            $sql->whereMonth('date', $month_year[0])->whereYear('date', $month_year[1]);
        }

        $total = $sql->count();
        if ($offset >= $total && $total > 0) {
            $lastPage = floor(($total - 1) / $limit) * $limit; // calculate last page offset
            $offset = $lastPage;
        }
        $sql->orderBy($sort, $order)->skip($offset)->take($limit);
        $res = $sql->get();
        $bulkData = array();
        $bulkData['total'] = $total;
        $rows = array();
        $no = $offset + 1;

        foreach ($res as $row) {
            $operate = '';
            if (!$row->month) {
                $operate .= BootstrapTableService::editButton(route('expense.update', $row->id));
                $operate .= BootstrapTableService::deleteButton(route('expense.destroy', $row->id));
            }

            $tempRow = $row->toArray();
            $tempRow['no'] = $no++;
            $tempRow['amount'] = $row->amount;
            if ($row->staff_id) {
                $tempRow['category.name'] = 'Salary';
            }
            $tempRow['operate'] = $operate;
            $rows[] = $tempRow;
        }

        $bulkData['rows'] = $rows;
        return response()->json($bulkData);
    }


    public function update(Request $request, $id)
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noPermissionThenSendJson('expense-edit');
        $sessionYearId = $this->cache->getSessionYear()->id;
        $request->validate([
            'ref_no' => [
                'nullable',
                Rule::unique('expenses', 'ref_no')
                    ->ignore($id) // Ignore current expense ID
                    ->where(function ($query) use ($sessionYearId) {
                        return $query->where('session_year_id', $sessionYearId)
                            ->whereNull('vehicle_id')
                            ->whereNull('staff_id');
                    }),
            ],
            'amount' => 'required|numeric|min:0'
        ], [
            'ref_no.unique' => 'Reference number already exists for the selected session year.'
        ]);
        try {
            DB::beginTransaction();
            $schoolSettings = $this->cache->getSchoolSettings();
            $data = [
                'category_id' => $request->category_id,
                'title' => $request->title,
                'ref_no' => $request->ref_no,
                'amount' => $request->amount,
                'date' => $request->date
                    ? Carbon::createFromFormat($schoolSettings['date_format'], $request->date)->format('Y-m-d')
                    : null,
                'description' => $request->description,
                'session_year_id' => $sessionYearId,
            ];
            $this->expense->update($id, $data);
            DB::commit();
            ResponseService::successResponse('Data Updated Successfully');
        } catch (Throwable $e) {
            DB::rollBack();
            ResponseService::logErrorResponse($e, "Expense Controller -> Update Method");
            ResponseService::errorResponse();
        }
    }


    public function destroy($id)
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noPermissionThenSendJson('expense-delete');

        try {
            DB::beginTransaction();
            $this->expense->deleteById($id);
            DB::commit();
            ResponseService::successResponse('Data Deleted Successfully');
        } catch (Throwable $e) {
            DB::rollBack();
            ResponseService::logErrorResponse($e, "Expense Controller -> Destroy Method");
            ResponseService::errorResponse();
        }
    }

    public function filter_graph($session_year_id, \App\Services\IncomeService $incomeService, \App\Services\ExpenseService $expenseService)
    {
        ResponseService::noFeatureThenRedirect('Finance Management');
        ResponseService::noAnyPermissionThenSendJson(['expense-create', 'expense-list']);

        try {
            if ($session_year_id == 'undefined' || $session_year_id == '') {
                $session_year_id = $this->cache->getSessionYear()->id;
            }

            $sessionYear = $this->sessionYear->builder()->findOrFail($session_year_id);

            $incomeData = $incomeService->monthlyBreakdown($sessionYear);
            $expenseData = $expenseService->monthlyBreakdown($sessionYear);

            $data = [
                'months' => $incomeData['labels'],
                'income' => [
                    'fee' => $incomeData['fee'],
                    'transport' => $incomeData['transport'],
                    'manual' => $incomeData['manual'],
                ],
                'expense' => [
                    'subscription' => $expenseData['subscription'],
                    'discount' => $expenseData['discount'],
                    'manual' => $expenseData['manual'],
                ]
            ];

            ResponseService::successResponse('Data Fetched Successfully', $data);
        } catch (Throwable $e) {
            DB::rollBack();
            ResponseService::logErrorResponse($e, "Expense Controller -> Filter Method");
            ResponseService::errorResponse();
        }
    }
}
