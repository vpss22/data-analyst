<?php

namespace App\Http\Controllers;

use App\Repositories\Guidance\GuidanceInterface;
use App\Services\BootstrapTableService;
use App\Services\CachingService;
use App\Services\ResponseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Throwable;

class GuidanceController extends Controller
{
    private GuidanceInterface $guidance;
    private CachingService $cache;

    public function __construct(GuidanceInterface $guidance, CachingService $cache)
    {
        $this->guidance = $guidance;
        $this->cache = $cache;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        ResponseService::noAnyPermissionThenRedirect(['guidance-list', 'guidance-create']);

        return view('guidance.index');

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        ResponseService::noPermissionThenRedirect('guidance-create');
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'link' => 'required|url',
        ]);

        if ($validator->fails()) {
            ResponseService::errorResponse($validator->errors()->first());
        }
        try {
            $this->guidance->create($request->all());
            $this->cache->removeSystemCache(config('constants.CACHE.SYSTEM.GUIDANCES'));
            ResponseService::successResponse('Data Stored Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e, "Guidance Controller -> Store Method");
            ResponseService::errorResponse();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        //
        ResponseService::noPermissionThenRedirect('guidance-list');
        $offset = request('offset', 0);
        $limit = request('limit', 10);
        $sort = request('sort', 'id');
        $order = request('order', 'DESC');
        $search = request('search');

        $sql = $this->guidance->builder()
            ->when($search, function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('id', 'LIKE', "%$search%")->orwhere('name', 'LIKE', "%$search%")->orwhere('link', 'LIKE', "%$search%");
                });
            });

        $total = $sql->count();
        if ($offset >= $total && $total > 0) {
            $lastPage = floor(($total - 1) / $limit) * $limit; // calculate last page offset
            $offset = $lastPage;
        }
        $sql->orderBy($sort, $order)->skip($offset)->take($limit);
        $res = $sql->get();

        $bulkData = array();
        $bulkData['total'] = $total;
        $rows = array();
        $no = 1;
        foreach ($res as $row) {
            $operate = BootstrapTableService::editButton(route('guidances.update', $row->id));
            $operate .= BootstrapTableService::deleteButton(route('guidances.destroy', $row->id));
            $tempRow = $row->toArray();
            $tempRow['no'] = $no++;
            $tempRow['operate'] = $operate;
            $rows[] = $tempRow;
        }
        $bulkData['rows'] = $rows;
        return response()->json($bulkData);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        //
        ResponseService::noPermissionThenSendJson('guidance-edit');
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'link' => 'required|url',
        ]);

        if ($validator->fails()) {
            ResponseService::errorResponse($validator->errors()->first());
        }
        try {
            $this->guidance->update($id, $request->all());
            $this->cache->removeSystemCache(config('constants.CACHE.SYSTEM.GUIDANCES'));
            ResponseService::successResponse('Data Updated Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e, "Guidance Controller -> Update Method");
            ResponseService::errorResponse();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        ResponseService::noPermissionThenSendJson('guidance-delete');
        try {
            $this->guidance->deleteById($id);
            ResponseService::successResponse('Data Deleted Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e, "Guidance Controller -> Destroy Method");
            ResponseService::errorResponse();
        }
    }
}
