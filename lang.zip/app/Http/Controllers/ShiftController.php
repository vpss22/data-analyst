<?php

namespace App\Http\Controllers;

use App\Models\ClassSchool;
use App\Models\shift;
use App\Repositories\Shift\ShiftInterface;
use App\Rules\uniqueForSchool;
use App\Services\BootstrapTableService;
use App\Services\ResponseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Throwable;


class ShiftController extends Controller
{

    private ShiftInterface $shift;

    public function __construct(ShiftInterface $shift)
    {
        $this->shift = $shift;
    }

    public function index()
    {
        ResponseService::noPermissionThenRedirect('shift-list');
        $shifts = $this->shift->builder()->orderBy('id', 'DESC')->get();
        return response(view('shift.index', compact('shifts')));
    }


    public function store(Request $request)
    {
        ResponseService::noPermissionThenSendJson('shift-create');

        $validator = Validator::make($request->all(), [
            'name' => ['required', new uniqueForSchool('shifts', 'name')],
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'full_day_minutes' => 'nullable|integer|min:1',
            'half_day_minutes' => 'nullable|integer|min:1|lt:full_day_minutes',
        ]);

        $validator->after(function ($validator) use ($request) {
            $this->validateThresholds($validator, $request);
        });

        if ($validator->fails()) {
            ResponseService::errorResponse($validator->errors()->first());
        }
        try {
            $this->shift->create($request->all());
            ResponseService::successResponse('Data Stored Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e);
            ResponseService::errorResponse();
        }
    }

    public function show(Request $request)
    {
        ResponseService::noPermissionThenRedirect('shift-list');

        $offset = request('offset', 0);
        $limit = request('limit', 10);
        $sort = request('sort', 'id');
        $order = request('order', 'DESC');

        $sql = $this->shift->builder()->where('id', '!=', 0);
        if (!empty($_GET['search'])) {
            $search = $_GET['search'];
            $sql->where(function ($query) use ($search) {
                $query->where('id', 'LIKE', "%$search%")->orwhere('name', 'LIKE', "%$search%");
            });
        }

        if ($request->show_deleted) {
            $sql->onlyTrashed();
        }
        $total = $sql->count();
        if ($offset >= $total && $total > 0) {
            $lastPage = floor(($total - 1) / $limit) * $limit; // calculate last page offset
            $offset = $lastPage;
        }
        $sql->orderBy($sort, $order)->skip($offset)->take($limit);
        $res = $sql->get();

        $bulkData = array();
        $bulkData['total'] = $total;
        $rows = array();
        $no = 1;
        foreach ($res as $row) {
            if ($request->show_deleted) {
                //Show Restore and Hard Delete Buttons
                $operate = BootstrapTableService::restoreButton(route('shift.restore', $row->id));
                $operate .= BootstrapTableService::trashButton(route('shift.trash', $row->id));
            } else {
                $operate = BootstrapTableService::editButton(route('shift.update', $row->id));
                $operate .= BootstrapTableService::deleteButton(route('shift.destroy', $row->id));
            }
            $tempRow = $row->toArray();
            $tempRow['no'] = $no++;
            $tempRow['operate'] = $operate;
            $rows[] = $tempRow;
        }

        $bulkData['rows'] = $rows;
        return response()->json($bulkData);
    }


    public function update(Request $request, $id)
    {
        ResponseService::noPermissionThenSendJson('shift-edit');

        $validator = Validator::make($request->all(), [
            'name' => ['required', new uniqueForSchool('shifts', 'name', $id)],
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'full_day_minutes' => 'nullable|integer|min:1',
            'half_day_minutes' => 'nullable|integer|min:1|lt:full_day_minutes',
        ]);

        $validator->after(function ($validator) use ($request) {
            $this->validateThresholds($validator, $request);
        });

        if ($validator->fails()) {
            ResponseService::errorResponse($validator->errors()->first());
        }
        try {
            $this->shift->update($id, $request->all());
            ResponseService::successResponse('Data Updated Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e);
            ResponseService::errorResponse();
        }
    }

    /**
     * Attendance thresholds must satisfy:
     *   half day < full day <= shift duration
     *
     * Whole minutes only — decimal hours invite the 4.99-hour rounding bug.
     */
    private function validateThresholds($validator, Request $request): void
    {
        $fullDay = $request->input('full_day_minutes');
        if (empty($fullDay)) {
            return;
        }

        $start = strtotime($request->input('start_time'));
        $end   = strtotime($request->input('end_time'));

        if ($start === false || $end === false || $end <= $start) {
            return;
        }

        $duration = (int) round(($end - $start) / 60);

        if ((int) $fullDay > $duration) {
            $validator->errors()->add(
                'full_day_minutes',
                trans('validation.lte.numeric', ['attribute' => trans('full_day_minutes'), 'value' => $duration])
            );
        }
    }

    public function destroy($id)
    {
        ResponseService::noPermissionThenSendJson('shift-delete');
        try {
            // Safety Check: Prevent deletion if shift is assigned to any class in any session
            if (ClassSchool::where('shift_id', $id)->exists()) {
                return ResponseService::errorResponse("Cannot delete this shift because it is associated with classes in academic sessions. Please remove those associations first.");
            }
            Shift::find($id)->delete();
            ResponseService::successResponse('Data Deleted Successfully');
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e);
            ResponseService::errorResponse();
        }
    }

    public function restore(int $id)
    {
        ResponseService::noPermissionThenSendJson('shift-delete');
        try {
            $this->shift->findOnlyTrashedById($id)->restore();
            ResponseService::successResponse("Data Restored Successfully");
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e);
            ResponseService::errorResponse();
        }
    }

    public function trash($id)
    {
        ResponseService::noPermissionThenSendJson('shift-delete');
        try {
            // Safety Check: Prevent permanent deletion if shift is assigned to any class in any session
            if (ClassSchool::where('shift_id', $id)->exists()) {
                return ResponseService::errorResponse("Cannot delete this shift permanently because it is associated with classes in academic sessions. Please remove those associations first.");
            }
            $this->shift->findOnlyTrashedById($id)->forceDelete();
            ResponseService::successResponse("Data Deleted Permanently");
        } catch (Throwable $e) {
            ResponseService::logErrorResponse($e, "Shift Controller -> Trash Method", 'cannot_delete_because_data_is_associated_with_other_data');
            ResponseService::errorResponse();
        }
    }
}
