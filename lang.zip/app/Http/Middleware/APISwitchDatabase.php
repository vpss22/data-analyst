<?php

namespace App\Http\Middleware;

use App\Models\School;
use App\Services\CachingService;
use Auth;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\PersonalAccessToken;
use Symfony\Component\HttpFoundation\Response;

class APISwitchDatabase
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {





        // Check system maintenance
        // $systemSettings = app(CachingService::class)->getSystemSettings();
        // if ($systemSettings && $systemSettings['web_maintenance'] == 1) {
        //     return response()->json(array('error' => true, 'message' => 'System is under maintenance.', 'code' => 425));
        // }

        $schoolCode = $request->header('school-code');
        if ($schoolCode) {
            $school = School::on('mysql')->where('code', $schoolCode)->first();

            if ($school) {
                DB::setDefaultConnection('school');
                Config::set('database.connections.school.database', $school->database_name);
                DB::purge('school');
                DB::connection('school')->reconnect();
                DB::setDefaultConnection('school');
                $token = $request->bearerToken();
                $user = PersonalAccessToken::findToken($token);

                if ($user) {
                    Auth::loginUsingId($user->tokenable_id);
                    // get school default session year
                    if (Auth::user() && Auth::user()->hasRole('Student') && Auth::user()->school_id) {
                        $defaultSessionYear = app(CachingService::class)->getDefaultSessionYear(Auth::user()->school_id);

                        if ($defaultSessionYear && Auth::user()->studentWithoutOwner && $defaultSessionYear->id != Auth::user()->studentWithoutOwner->session_year_id) {
                            Auth::logout();
                            return response()->json(array('error' => true, 'message' => 'Unauthenticated.', 'code' => 401));
                        }
                    }
                } else {
                    return response()->json(array('error' => true, 'message' => 'Unauthenticated.', 'code' => 401));
                }

                $exclude_uri = array(
                    '/api/student/login',
                    '/api/parent/login',
                    '/api/teacher/login',
                    '/contact',
                    '/api/student/submit-online-exam-answers',
                    '/api/get-vehicle-assignment-status',
                    '/api/transport/requests',
                    '/api/transport/dashboard',
                    '/api/transport/plans/current',
                    '/api/transport/routes/stops',
                    '/api/transportation/live-route',
                    '/api/parent/fees/compulsory/pay',
                    '/api/parent/fees/optional/pay',
                    '/api/transportation-payments',
                    '/api/teacher/class-detail'
                );

                if (env('DEMO_MODE') && !$request->isMethod('get') && Auth::user() && !in_array($request->getRequestUri(), $exclude_uri)) {
                    return response()->json(array(
                        'error'   => true,
                        'message' => trans("this_is_not_allowed_in_the_demo_version"),
                        'code'    => 112
                    ));
                }
            } else {
                return response()->json(array('error' => true, 'message' => 'Invalid school code', 'code' => 400));
            }
        } else {
            return response()->json(array('error' => false, 'message' => 'School Code is Required', 'code' => 200));
        }

        return $next($request);
    }
}
